LiroycEffects uses the Rubik font (SIL Open Font License 1.1) for the whole interface.
Put Rubik-Regular.ttf, Rubik-Medium.ttf and Rubik-SemiBold.ttf (or the variable file
"Rubik[wght].ttf") in this folder, or in a "fonts" folder next to the program.
Run scripts/get-rubik.sh to download it.
