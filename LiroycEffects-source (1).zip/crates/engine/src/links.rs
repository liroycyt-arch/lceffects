//! The application's name. LiroycEffects has no external links.

pub const APP_NAME: &str = "LiroycEffects";
pub const APP_SLUG: &str = "liroyceffects";
